# 在线训练排查

配合 [SKILL.md](SKILL.md) 使用。按症状定位。

## 训练 CUDA OOM

症状：`torch.cuda.OutOfMemoryError`

处理：

1. 降低 `--total-seq-len`（如 `8192` → `4096`）
2. Eagle-3：减小 `--num-layers`（试 `1`）
3. DFlash/DSpark：减小 `--num-layers`、`--max-anchors` 或 `--block-size`
4. 训练侧加卡并 `torchrun --nproc_per_node N`；极大模型加 `--fsdp-shard`
5. 确认 `CUDA_VISIBLE_DEVICES` 未与 vLLM 重叠

## vLLM OOM / 起不来

症状：vLLM `CUDA out of memory` 或进程退出

处理：

```bash
python scripts/launch_vllm.py MODEL \
  -- --gpu-memory-utilization 0.9 \
  --max-model-len 4096 \
  --tensor-parallel-size 2
```

或增加 `--data-parallel-size` / 专用更多 GPU。

## 连不上 vLLM / 训练卡住等数据

检查：

1. `curl -sf http://localhost:8000/health`
2. `--vllm-endpoint` 是否为 `http://localhost:PORT/v1`（注意 `/v1`）
3. 防火墙 / 端口占用
4. 训练是否与 vLLM **抢同一张 GPU**（online 必须分卡）
5. 利用率忽高忽低：给 vLLM 更多 GPU，或改用 `--on-generate cache` / 离线训练

## `--target-layer-ids` 不一致

症状：shape 报错、hidden states 维数不对、训练异常

规则：

- DFlash/DSpark：launch 与 train 的 layer 列表必须相同
- 改过 launch 的 ids 后必须重启 server
- 注意默认会 **追加最后一层**（`--include-last-layer`）；自定义时两边行为要一致

用 dry-run 核对 launch 实际命令：

```bash
python scripts/launch_vllm.py MODEL --target-layer-ids 2 18 33 --dry-run -- --port 8000
```

## Loss 不降

1. 试更小 LR（Eagle-3：`1e-5`；DFlash/DSpark：`1e-4`）
2. 确认 `prepare_data` 产物存在且 `token_freq.pt` 非空
3. 优先做 response regeneration（on-policy）
4. 增加 `--epochs` 或样本量（5k 仅 sanity check）
5. 确认训练在跑 verifier 匹配的 `--data-path`（tokenizer/model 一致）

## 数据准备被跳过或 --overwrite 失败

- 输出目录已有完整 dataset 时会跳过；改配置后换新 `--output` 或加 `--overwrite`
- `--overwrite` 若发现非本脚本产物会拒绝删除——换目录或手动清理

## 响应重采样中断

```bash
python scripts/response_regeneration/script.py \
  --dataset sharegpt \
  --outfile ./sharegpt_Qwen3-8B.jsonl \
  --resume
```

## 5k 样本效果差是正常的

教程与 `examples/train/*_5k.sh` 明确：5k + 数 epoch 只验证流水线是否学会；生产需更多数据与更长训练。关注 loss 下降与 checkpoint 能否被 `vllm serve` 加载，而非立刻追高 acceptance length。

## 环境混用

| 步骤 | 环境 |
|------|------|
| `prepare_data.py` / `train.py` / `script.py` | speculators |
| `launch_vllm.py` / `vllm serve` / `run_all.sh` 内服务 | vLLM |

装错环境会出现 import 失败或版本冲突；实验 tracker 装在 speculators 侧。

## 继续训练 / 校验初始化

```bash
# 只构建并保存未训练权重，便于先在 vLLM 校验
python scripts/train.py ... --dry-run --save-path ./draft_init

# 从 checkpoint 接着训
python scripts/train.py ... --from-pretrained ./output/.../checkpoints/checkpoint_best
```

默认会自动从 `--save-path` 最新 checkpoint resume；若不需要：`--no-resume-from-checkpoint`。
