# 算法参数与完整命令

本文是 [SKILL.md](SKILL.md) 的展开：三种算法的差异、推荐超参、可复制命令。

## 差异速查

| 项 | Eagle-3 | DFlash | DSpark |
|----|---------|--------|--------|
| `--speculator-type` | `eagle3`（默认） | `dflash` | `dspark` |
| 草稿层风格 | Llama-style（`--draft-arch`） | Qwen3-style（固定） | 同 DFlash |
| 典型 `--num-layers` | `1` | `5` | `3`（小模型示例）或更大 |
| 预测方式 | 自回归逐步 draft | 一块 token 单次前向 | DFlash + Markov/Confidence |
| `--target-layer-ids` | 可省略（用默认） | **必须显式**，与 launch 一致 | **必须显式**，与 launch 一致 |
| 块相关参数 | 无 | `--block-size`、`--max-anchors` | 同 DFlash |
| DSpark 专有 | 无 | 无 | `--markov-*`、`--*confidence*`、`--loss-fn` |
| `sample_from_anchor` 默认 | N/A | `False`（产出 `block_size-1`） | `True`（产出 `block_size`） |
| 推荐起步 LR | `1e-4` | `3e-4` | `3e-4` |
| 示例脚本 | `examples/train/eagle3_qwen3_8b_sharegpt_online_5k.sh` | `examples/train/dflash_qwen3_8b_sharegpt_online_5k.sh` | `examples/train/dspark_qwen3_0_6b_sharegpt_online.sh` |

## Layer ID 怎么选

- **不传**：`launch_vllm.py` 使用 `[2, num_hidden_layers//2, num_hidden_layers-3]`，并默认追加最后一层。
- **手动传**：launch 与 train **必须相同**。示例：
  - Qwen3-8B（36 层量级）：`2 18 33`（DFlash 教程）
  - Qwen3-0.6B：`2 14 25`（DSpark 示例脚本）
- 改 layer 后必须重启 vLLM，并同步改 train 参数。

## Eagle-3 完整在线流程

假设：模型 `Qwen/Qwen3-8B`，已重采样到 `./sharegpt_Qwen3-8B.jsonl`，输出 `./output/eagle3_qwen3_8b_sharegpt`，vLLM 用 GPU 0–1，训练用 2–3。

```bash
# 1) 数据准备
python scripts/prepare_data.py \
  --model Qwen/Qwen3-8B \
  --data ./sharegpt_Qwen3-8B.jsonl \
  --output ./output/eagle3_qwen3_8b_sharegpt \
  --max-samples 5000 \
  --seq-length 8192

# 2) vLLM（另一终端，vLLM 环境）
CUDA_VISIBLE_DEVICES=0,1 python scripts/launch_vllm.py Qwen/Qwen3-8B \
  -- --data-parallel-size 2 --port 8000 --gpu-memory-utilization 0.85

# 3) 训练（speculators 环境）
CUDA_VISIBLE_DEVICES=2,3 torchrun --standalone --nproc_per_node 2 \
  scripts/train.py \
  --verifier-name-or-path Qwen/Qwen3-8B \
  --data-path ./output/eagle3_qwen3_8b_sharegpt \
  --vllm-endpoint http://localhost:8000/v1 \
  --save-path ./output/eagle3_qwen3_8b_sharegpt/checkpoints \
  --draft-vocab-size 32000 \
  --epochs 5 \
  --lr 1e-4 \
  --total-seq-len 8192 \
  --on-missing generate \
  --on-generate delete
```

单卡训练（且 vLLM 占另一卡）：

```bash
CUDA_VISIBLE_DEVICES=1 python scripts/train.py ...同上...
```

可选 Eagle-3 相关：`--ttt-steps`、`--norm-before-fc` / `--fc-norm`、`--norm-output`。新手保持默认即可。

## DFlash 完整在线流程

```bash
OUTPUT=./output/dflash_qwen3_8b_sharegpt
TARGET_LAYER_IDS="2 18 33"

python scripts/prepare_data.py \
  --model Qwen/Qwen3-8B \
  --data ./sharegpt_Qwen3-8B.jsonl \
  --output "$OUTPUT" \
  --max-samples 5000 \
  --seq-length 8192

CUDA_VISIBLE_DEVICES=0,1 python scripts/launch_vllm.py Qwen/Qwen3-8B \
  --target-layer-ids $TARGET_LAYER_IDS \
  -- --data-parallel-size 2 --port 8000

CUDA_VISIBLE_DEVICES=2,3 torchrun --standalone --nproc_per_node 2 \
  scripts/train.py \
  --verifier-name-or-path Qwen/Qwen3-8B \
  --data-path "$OUTPUT" \
  --vllm-endpoint http://localhost:8000/v1 \
  --save-path "$OUTPUT/checkpoints" \
  --speculator-type dflash \
  --block-size 8 \
  --max-anchors 3072 \
  --num-layers 5 \
  --draft-vocab-size 32000 \
  --target-layer-ids $TARGET_LAYER_IDS \
  --epochs 5 \
  --lr 3e-4 \
  --total-seq-len 8192 \
  --on-missing generate \
  --on-generate delete
```

### DFlash 参数说明

| 参数 | 典型值 | 含义 |
|------|--------|------|
| `--block-size` | `8` | 每块预测 token 数相关 |
| `--max-anchors` | `3072` | 训练时最大 anchor 数 |
| `--num-layers` | `5` | 草稿 transformer 层数 |
| `--dflash-decay-gamma` | `4.0` | 位置 loss 衰减 |
| `--no-sample-from-anchor` | 默认 | anchor 为 bonus；产出 `block_size-1` 个投机 token |

## DSpark 完整在线流程

DSpark = DFlash 骨干 + Markov logit bias + confidence head。流水线与 DFlash 相同，训练多几项 flag。

仓库示例用较小 verifier `Qwen/Qwen3-0.6B` 便于单机验证：

```bash
OUTPUT=./output/dspark_qwen3_0_6b_sharegpt
TARGET_LAYER_IDS="2 14 25"

python scripts/prepare_data.py \
  --model Qwen/Qwen3-0.6B \
  --data sharegpt \
  --output "$OUTPUT" \
  --max-samples 5000 \
  --seq-length 4096

CUDA_VISIBLE_DEVICES=0 python scripts/launch_vllm.py Qwen/Qwen3-0.6B \
  --target-layer-ids $TARGET_LAYER_IDS \
  -- --port 8000

CUDA_VISIBLE_DEVICES=1 torchrun --standalone --nproc_per_node 1 \
  scripts/train.py \
  --verifier-name-or-path Qwen/Qwen3-0.6B \
  --data-path "$OUTPUT" \
  --vllm-endpoint http://localhost:8000/v1 \
  --save-path "$OUTPUT/checkpoints" \
  --speculator-type dspark \
  --block-size 8 \
  --max-anchors 3072 \
  --num-layers 3 \
  --draft-vocab-size 32000 \
  --target-layer-ids $TARGET_LAYER_IDS \
  --markov-rank 256 \
  --markov-head-type vanilla \
  --enable-confidence-head \
  --confidence-head-with-markov \
  --loss-fn '{"ce": 0.1, "tv": 0.9}' \
  --confidence-head-alpha 1.0 \
  --epochs 5 \
  --lr 3e-4 \
  --total-seq-len 4096 \
  --on-missing generate \
  --on-generate delete
```

换更大 verifier（如 Qwen3-8B）时：沿用 DFlash 的 layer ids / GPU 划分，仅把 `--speculator-type` 与 DSpark 头相关参数加上。

### DSpark 专有参数

| 参数 | 典型值 | 含义 |
|------|--------|------|
| `--markov-rank` | `256` | Markov 低秩维；`0` 关闭 |
| `--markov-head-type` | `vanilla` | `vanilla` / `gated` / `rnn` |
| `--enable-confidence-head` | 开 | 每位置接受概率头 |
| `--confidence-head-with-markov` | 开 | confidence 输入含 Markov embedding（需 `markov_rank>0`） |
| `--confidence-head-alpha` | `1.0` | confidence BCE 权重 |
| `--loss-fn` | 见示例 | 复合 loss；也可用默认 KL |

## 响应重采样 → prepare_data 衔接

```bash
./scripts/response_regeneration/run_all.sh \
  --model "Qwen/Qwen3-8B" \
  --dataset sharegpt \
  --limit 5000 \
  --outfile ./sharegpt_Qwen3-8B.jsonl

python scripts/prepare_data.py \
  --model Qwen/Qwen3-8B \
  --data ./sharegpt_Qwen3-8B.jsonl \
  --output ./output/<algo>_qwen3_8b_sharegpt \
  --seq-length 8192
```

三种算法的 Phase 1–2 **相同**；从 Phase 3 开始分叉。

## 混合训练（可选）

首 epoch 在线生成并缓存，后续读盘：

```bash
python scripts/train.py \
  ... \
  --hidden-states-path ./output/.../hidden_states \
  --on-missing generate \
  --on-generate cache
```

GPU 紧张、训练利用率抖动时，可考虑改走离线 datagen（超出本 Skill 范围，见 offline 教程）。
