---
name: online-draft-training
description: >-
  Guides end-to-end online draft/speculator training for Eagle-3, DFlash, or
  DSpark via response regeneration, prepare_data.py, launch_vllm.py, and
  train.py. Use when the user asks to train a draft model, speculative decoding
  drafter, eagle3, dflash, dspark, online training, or complete the four-step
  Speculators training pipeline.
---

# 在线草稿模型训练（Eagle-3 / DFlash / DSpark）

带领用户完成 **online**（在线）草稿模型训练全流程。假设用户没有 speculative decoding 背景；先建立最小概念，再按固定四步执行。

官方教程入口：[Tutorials](https://docs.vllm.ai/projects/speculators/en/latest/user_guide/tutorials/)

## 何时使用本 Skill

用户提到以下任一内容时启用：

- 训练草稿模型 / draft / speculator / speculative decoding
- Eagle-3、DFlash、DSpark 在线训练
- `response_regeneration`、`prepare_data.py`、`launch_vllm.py`、`train.py`

本 Skill **只覆盖在线训练**。离线 hidden states 生成不在范围内。

## 最小概念（先讲给用户）

| 术语 | 含义 |
|------|------|
| Target / Verifier | 要加速的大模型（如 `Qwen/Qwen3-8B`） |
| Draft / Speculator | 要训练的小草稿模型，负责快速猜下一组 token |
| Online training | 训练时通过 vLLM 实时抽取 verifier 的 hidden states，不预先落盘全量缓存 |
| On-policy 数据 | 用 target 自己重新生成 assistant 回复；对齐更好，推荐 |
| Off-policy 数据 | 直接用数据集原始回复；更快但接受长度通常更差 |

三条算法的共同点：同一套四步流水线。差异几乎都在 **拉起 vLLM 的 layer ids** 与 **`train.py` 的算法参数**。

## 进度清单

复制并跟踪：

```
- [ ] 0. 确认算法、目标模型、GPU 划分、环境
- [ ] 1. 数据重采样 scripts/response_regeneration/script.py（强烈推荐）
- [ ] 2. 数据准备 scripts/prepare_data.py
- [ ] 3. 拉起 vLLM scripts/launch_vllm.py（训练全程保持运行）
- [ ] 4. 训练 scripts/train.py
- [ ] 5. 检查 checkpoint，可选 serve 验证
```

## Phase 0：收集决策

在跑任何命令前，向用户确认（缺省则用括号内默认值）：

1. **算法**：`eagle3`（新手默认）/ `dflash` / `dspark`
2. **目标模型**：如 `Qwen/Qwen3-8B`（DSpark 示例常用 `Qwen/Qwen3-0.6B`）
3. **数据集**：内置 `sharegpt` / `ultrachat`，或自定义 JSONL / 重采样输出
4. **是否做响应重采样**：是（推荐）/ 否（off-policy 快速试跑）
5. **样本量**：试跑 `5000`；生产用更大
6. **GPU 划分**：online 需要 **vLLM 与训练分卡**。示例：`VLLM_GPUS=0,1`，`TRAIN_GPUS=2,3`
7. **输出目录**：如 `./output/<algo>_<model>_<dataset>`

算法选型一句话：

- 不确定 → **Eagle-3**（文档与生态最成熟）
- 想单次前向预测一整块 token → **DFlash**
- 在 DFlash 上再加块内 token 依赖（Markov）与接受置信度头 → **DSpark**

详细参数表见 [algorithms.md](algorithms.md)。

## Phase 0.5：环境

推荐两个独立 venv，避免依赖冲突：

```bash
# Speculators：数据准备 + 训练
uv venv speculators_venv
source speculators_venv/bin/activate   # Windows: speculators_venv\Scripts\activate
uv pip install -e ".[dev]"             # 或在本仓库按 README 安装可编辑包

# vLLM：serving / hidden states（版本需满足仓库要求，教程常用 >=0.18）
uv venv vllm_venv
source vllm_venv/bin/activate
uv pip install "vllm>=0.18"
```

- `prepare_data.py`、`train.py`、`response_regeneration/script.py` → **speculators** 环境
- `launch_vllm.py`、响应重采样时的 `vllm serve` / `run_all.sh` → **vLLM** 环境
- 若用 wandb/trackio/tensorboard/mlflow，装在 **speculators** 环境

## Phase 1：数据重采样（强烈推荐）

目标：用 target 模型重写 assistant 回复，得到 on-policy JSONL。

### 推荐：一键脚本

```bash
# 在 vLLM 可用的环境中
./scripts/response_regeneration/run_all.sh \
  --model "Qwen/Qwen3-8B" \
  --dataset sharegpt \
  --limit 5000 \
  --outfile ./sharegpt_Qwen3-8B.jsonl
```

多卡示例：`--dp-size 2`、`--tp-size 2`、`--gpus 0,1,2,3`。

### 手动：已有 vLLM 服务时

```bash
# 终端 A：普通 chat serving（重采样不需要 hidden states connector）
vllm serve "Qwen/Qwen3-8B" --port 8000

# 终端 B：speculators 环境
python scripts/response_regeneration/script.py \
  --dataset sharegpt \
  --limit 5000 \
  --endpoint http://127.0.0.1:8000/v1/chat/completions \
  --outfile ./sharegpt_Qwen3-8B.jsonl
```

中断后续跑加 `--resume`。

### 验收

```bash
wc -l ./sharegpt_Qwen3-8B.jsonl
head -1 ./sharegpt_Qwen3-8B.jsonl | python -m json.tool
```

每行应含 `input_ids`、`loss_mask`、`conversations`。`loss_mask`：prompt 为 0，生成 token 为 1。

跳过本步时：Phase 2 的 `--data` 直接用 `sharegpt` / `ultrachat` / 原始 JSONL。

参考：[Response Regeneration](https://docs.vllm.ai/projects/speculators/en/latest/user_guide/tutorials/response_regeneration/)

## Phase 2：数据准备

```bash
# speculators 环境
python scripts/prepare_data.py \
  --model Qwen/Qwen3-8B \
  --data ./sharegpt_Qwen3-8B.jsonl \
  --output ./output/eagle3_qwen3_8b_sharegpt \
  --max-samples 5000 \
  --seq-length 8192
```

Off-policy 快速试跑：把 `--data` 换成 `sharegpt` 或 `ultrachat`。

### 关键参数

| 参数 | 作用 |
|------|------|
| `--model` | 与训练 verifier **同一** tokenizer / chat template |
| `--data` | 内置名、JSONL 路径；可重复传入多个 |
| `--output` | 处理后的 HuggingFace dataset 目录 |
| `--seq-length` | 截断长度；后续 `--total-seq-len` 通常与此一致 |
| `--max-samples` | 试跑限流 |
| `--overwrite` | 强制重跑（仅允许覆盖本脚本产物） |

### 验收

`output/` 下应有 `.arrow` shards、`dataset_info.json`、`state.json`、`token_freq.pt`。

输出目录已存在且完整时会跳过；不要误删用户其他文件。

## Phase 3：拉起 vLLM（训练用 hidden states）

**必须与 Phase 4 同时存活。** GPU 与训练进程分离。

### Eagle-3（可用默认 layer）

```bash
# vLLM 环境
CUDA_VISIBLE_DEVICES=0,1 python scripts/launch_vllm.py Qwen/Qwen3-8B \
  -- --data-parallel-size 2 --port 8000 --gpu-memory-utilization 0.85
```

### DFlash / DSpark（必须显式传 layer ids）

```bash
# Qwen3-8B DFlash 示例
CUDA_VISIBLE_DEVICES=0,1 python scripts/launch_vllm.py Qwen/Qwen3-8B \
  --target-layer-ids 2 18 33 \
  -- --data-parallel-size 2 --port 8000

# Qwen3-0.6B DSpark 示例
CUDA_VISIBLE_DEVICES=0 python scripts/launch_vllm.py Qwen/Qwen3-0.6B \
  --target-layer-ids 2 14 25 \
  -- --port 8000
```

**硬性规则**：若传了 `--target-layer-ids`，`train.py` 必须传 **完全相同** 的 ids。默认值约为 `[2, num_layers//2, num_layers-3]`，且默认会追加最后一层（`--include-last-layer`）。

就绪信号：日志出现 `Application startup complete`，或：

```bash
curl -sf http://localhost:8000/health
```

`--` 之后参数原样传给 vLLM（`--port`、`--data-parallel-size`、`--tensor-parallel-size`、`--max-model-len` 等）。

## Phase 4：训练

等 Phase 3 ready 后，在 **另一终端**、**另一组 GPU**、**speculators 环境** 启动。

完整命令模板按算法见 [algorithms.md](algorithms.md)。下面是最短对照。

### Eagle-3

```bash
CUDA_VISIBLE_DEVICES=2,3 torchrun --standalone --nproc_per_node 2 \
  scripts/train.py \
  --verifier-name-or-path Qwen/Qwen3-8B \
  --data-path ./output/eagle3_qwen3_8b_sharegpt \
  --vllm-endpoint http://localhost:8000/v1 \
  --save-path ./output/eagle3_qwen3_8b_sharegpt/checkpoints \
  --draft-vocab-size 32000 \
  --epochs 5 --lr 1e-4 --total-seq-len 8192 \
  --on-missing generate --on-generate delete
```

（默认 `--speculator-type eagle3`，通常 `--num-layers 1`。）

### DFlash

在 Eagle-3 基础上增加：

```text
--speculator-type dflash
--block-size 8 --max-anchors 3072 --num-layers 5
--target-layer-ids 2 18 33
--lr 3e-4
```

### DSpark

在 DFlash 基础上改为 `--speculator-type dspark`，并增加：

```text
--markov-rank 256
--markov-head-type vanilla
--enable-confidence-head
--confidence-head-with-markov
--loss-fn '{"ce": 0.1, "tv": 0.9}'
--confidence-head-alpha 1.0
```

`sample_from_anchor` 默认：DFlash=`False`，DSpark=`True`（一般不要改，除非你清楚推理侧配置）。

### Online 关键开关

| 参数 | 推荐 | 含义 |
|------|------|------|
| `--on-missing generate` | 必须 | 缺 hidden states 时向 vLLM 实时请求 |
| `--on-generate delete` | 省盘 | 用完即删 |
| `--on-generate cache` | 混合 | 首 epoch 缓存，后续复用（需 `--hidden-states-path`） |
| `--vllm-endpoint` | `http://localhost:8000/v1` | 与 Phase 3 端口一致 |

现成一键脚本（可复制改配置）：

- `examples/train/eagle3_qwen3_8b_sharegpt_online_5k.sh`
- `examples/train/dflash_qwen3_8b_sharegpt_online_5k.sh`
- `examples/train/dspark_qwen3_0_6b_sharegpt_online.sh`

## Phase 5：验收与下一步

Checkpoint 目录典型结构：

```text
checkpoints/
├── 0/ … N/          # 各 epoch
└── checkpoint_best  # 指向验证集 loss 最低的 epoch（若启用）
```

每个 epoch 目录含可部署的完整 speculator（`config.json` + weights），以及可选的 optimizer/scheduler 状态。

快速验证（先停掉训练用的 vLLM）：

```bash
vllm serve ./output/.../checkpoints/checkpoint_best --port 8000
vllm chat --url http://localhost:8000/v1
```

后续：

- 评测：[Evaluating Performance](https://docs.vllm.ai/projects/speculators/en/latest/user_guide/tutorials/evaluating_performance/)
- 部署：[Serve in vLLM](https://docs.vllm.ai/projects/speculators/en/latest/user_guide/tutorials/serve_vllm/)
- 继续训：`--from-pretrained ./.../checkpoint_best`

## Agent 行为规范

1. **先确认算法与 GPU，再执行**；不要默认开跑大模型全量数据。
2. 新手默认路径：Eagle-3 + ShareGPT 5k + 推荐做重采样。
3. 命令优先复用本仓库 `examples/train/*.sh`，再按用户模型改变量。
4. DFlash/DSpark：**launch 与 train 的 `--target-layer-ids` 必须一致**。
5. 训练前确认 `curl` health 通过；训练 OOM / vLLM OOM / loss 不降见 [troubleshooting.md](troubleshooting.md)。
6. Windows 用户：路径用正斜杠；bash 示例可在 WSL/Git Bash 运行；PowerShell 需拆成多终端等价步骤。
7. 不要擅自 `git commit`；不要把密钥写进命令或文档。

## 附加资源

- 算法命令与参数对照：[algorithms.md](algorithms.md)
- 常见问题：[troubleshooting.md](troubleshooting.md)
- Eagle-3 在线教程：https://docs.vllm.ai/projects/speculators/en/latest/user_guide/tutorials/train_eagle3_online/
- DFlash 在线教程：https://docs.vllm.ai/projects/speculators/en/latest/user_guide/tutorials/train_dflash_online/
- CLI：`docs/cli/prepare_data.md`、`docs/cli/launch_vllm.md`、`docs/cli/train.md`、`docs/cli/response_regeneration.md`
